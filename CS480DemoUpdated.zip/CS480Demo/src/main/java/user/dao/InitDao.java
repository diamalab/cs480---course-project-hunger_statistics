package user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.domain.User;



/**
 * DDL functions performed in database
 * @author changxin bai
 *
 */
public class InitDao {    
	
	public void initDB() {
		Statement statement;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();;
			Connection connect;
			try {
				connect = DriverManager
				          .getConnection("jdbc:mysql://localhost:3306/bookstore?"
					              + "user=root&password=K0u39571");
				statement = connect.createStatement();
				statement.executeUpdate("DROP DATABASE bookstore;");
			}
			catch(SQLException e) {
			
				connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/hunger_statistics?"
				              + "user=root&password=K0u39571");
				statement = connect.createStatement();
				statement.executeUpdate("DROP TABLE IF EXISTS financial_condition;");
				statement.executeUpdate("DROP TABLE IF EXISTS people_starving;");
				statement.executeUpdate("DROP TABLE IF EXISTS resources_collected;");
				statement.executeUpdate("DROP TABLE IF EXISTS state;");
				
				String sqlInit = "CREATE TABLE IF NOT EXISTS state "
						+ "	(total_population INT UNSIGNED,"
						+ "    total_starving INT UNSIGNED,"
						+ "    resources SMALLINT UNSIGNED"
						+ ")";
				statement.executeUpdate(sqlInit);
				
				sqlInit =  "CREATE TABLE IF NOT EXISTS people_starving ("
						+ "	birth_date DATE,"
						+ "    name_person CHAR(60),"
						+ "    state CHAR(20)"
						+ ")";
				statement.executeUpdate(sqlInit);
				
				sqlInit =  "CREATE TABLE IF NOT EXISTS financial_condition ("
						+ "	income INT UNSIGNED,"
						+ "    own_house VARCHAR(3),"
						+ "    job CHAR(60)"
						+ ")";
				statement.executeUpdate(sqlInit);
				
				sqlInit = "CREATE TABLE IF NOT EXISTS resources_collected ("
						+ "	necessities CHAR (60),"
						+ "    food SMALLINT UNSIGNED,"
						+ "    water SMALLINT UNSIGNED"
						+ ")";
				statement.executeUpdate(sqlInit);
				
				sqlInit = "INSERT INTO state VALUES (1000000000,1000000,50000),\r\n"
						+ "(999,99,9),\r\n"
						+ "(10000,1000,100)\r\n";
				statement.executeUpdate(sqlInit);
				
				sqlInit = "INSERT INTO people_starving VALUES(03/30/1999,\"Jack\",\"Ohio\"),\r\n"
				+ "(11/16/1999,\"Angel\",\"Washington\"),\r\n"
				+ "(10/26/1998,\"Sam\",\"Indiana\")\r\n";
				statement.executeUpdate(sqlInit);
				
				sqlInit = "INSERT INTO financial_condition VALUES (20000,\"No\",\"Labor\"),\r\n"
				+ "(25000,\"No\",\"Labor\"),\r\n"
				+ "(30000,\"Yes\",\"Janitor\")\r\n";
				statement.executeUpdate(sqlInit);
				
				sqlInit = "INSERT INTO resources_collected VALUES(\"Place, Toiletries\",5,10),\r\n"
				+ "(\"Place, Toiletries, medicines\",3,15),\r\n"
				+ "(\"Toiletries\", 10, 17);";
				
			}
		    
		} catch(SQLException | InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	
	
	/**
	 * insert User
	 * @param user
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void add(User user) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/hunger_statistics?"
				              + "user=root&password=K0u39571");
						
			String sql = "insert into people_starving values(?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setString(1,user.getUsername());
		    preparestatement.setString(2,user.getPassword());
		    preparestatement.setString(3,user.getEmail());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	public List<Object> findall() throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		List<Object> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/hunger_statistics?"
				              + "user=root&password=K0u39571");
			
			String sql = "select * from people_starving";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			ResultSet resultSet = preparestatement.executeQuery();
			
			while(resultSet.next()){
				User user = new User();
				user.setUsername(resultSet.getString("name_person"));
	    		user.setPassword(resultSet.getString("state"));
	    		user.setEmail(resultSet.getString("birth_date"));
	    		list.add(user);
			 }
			 
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		return list;
		
	}
		
}

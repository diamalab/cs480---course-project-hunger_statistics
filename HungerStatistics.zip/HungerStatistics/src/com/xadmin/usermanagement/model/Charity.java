package com.xadmin.usermanagement.model;

public class Charity {
	protected String charity_id;
	protected String food_pantry;
	protected String people_shelter;
	protected int ssn;
	protected int id;
	
	public Charity() {
	}
	
	public Charity(String charity_id, String food_pantry, String people_shelter, int ssn) {
		super();
		this.charity_id = charity_id;
		this.food_pantry = food_pantry;
		this.people_shelter = people_shelter;
		this.ssn = ssn;
	}

	public Charity(int id, String charity_id, String food_pantry, String people_shelter, int ssn) {
		super();
		this.id = id;
		this.charity_id = charity_id;
		this.food_pantry = food_pantry;
		this.people_shelter = people_shelter;
		this.ssn = ssn;
	}

	public String getCharity_id() {
		return charity_id;
	}

	public void setCharity_id(String charity_id) {
		this.charity_id = charity_id;
	}

	public String getFood_pantry() {
		return food_pantry;
	}

	public void setFood_pantry(String food_pantry) {
		this.food_pantry = food_pantry;
	}

	public String getPeople_shelter() {
		return people_shelter;
	}

	public void setPeople_shelter(String people_shelter) {
		this.people_shelter = people_shelter;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
}
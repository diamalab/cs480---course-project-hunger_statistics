package com.xadmin.usermanagement.model;

public class State {
	protected int total_population;
	protected int total_starving;
	protected int resources;
	protected String state_name;
	protected String state_id;
	private int id;
	
	public State() {
	}
	
	public State(int total_population, int total_starving, int resources, String state_name, String state_id) {
		super();
		this.total_population = total_population;
		this.total_starving = total_starving;
		this.resources = resources;
		this.state_name = state_name;
		this.state_id = state_id;
	}
	
	public State(String state_name, String state_id, int resources) {
		super();
		this.resources = resources;
		this.state_name = state_name;
		this.state_id = state_id;
	}

	public State(int id, int total_population, int total_starving, int resources, String state_name, String state_id) {
		super();
		this.id = id;
		this.total_population = total_population;
		this.total_starving = total_starving;
		this.resources = resources;
		this.state_name = state_name;
		this.state_id = state_id;
	}

	public State(String state_name2, int total_population2, int total_starving2) {
		// TODO Auto-generated constructor stub
		super();
		this.total_population = total_population2;
		this.total_starving = total_starving2;
		this.state_name = state_name2;
	}

	public int getTotal_population() {
		return total_population;
	}

	public void setTotal_population(int total_population) {
		this.total_population = total_population;
	}

	public int getTotal_starving() {
		return total_starving;
	}

	public void setTotal_starving(int total_starving) {
		this.total_starving = total_starving;
	}

	public int getResources() {
		return resources;
	}

	public void setResources(int resources) {
		this.resources = resources;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public String getState_id() {
		return state_id;
	}

	public void setState_id(String state_id) {
		this.state_id = state_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
package com.xadmin.usermanagement.model;

public class Query5 {
	protected String State;
	
	public Query5(String State) {
		super();
		this.State = State;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}	
	
	
}
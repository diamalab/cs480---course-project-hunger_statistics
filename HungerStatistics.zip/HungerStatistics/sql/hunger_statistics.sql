Create database hunger_statistics;
use  hunger_statistics;
CREATE TABLE state (
id int NOT NULL AUTO_INCREMENT, 
	total_population INT UNSIGNED,
    total_starving INT UNSIGNED,
    resources SMALLINT UNSIGNED,
    state_name CHAR(20),
    state_id CHAR(3),
    PRIMARY KEY (id, state_id)
);

CREATE TABLE people_starving (
	id int NOT NULL AUTO_INCREMENT, 
	birth_date CHAR(15),
    name_person CHAR(60),
    ssn INT UNSIGNED,
    state_id CHAR(3),
    PRIMARY KEY (id, ssn),
    FOREIGN KEY (id, state_id) REFERENCES state(id, state_id)
);

CREATE TABLE financial_condition (
	id int NOT NULL AUTO_INCREMENT, 
	people_income INT UNSIGNED,
    own_house VARCHAR(20),
    people_job VARCHAR(20),
    people_expenses INT UNSIGNED,
    people_rent INT UNSIGNED,
    ssn INT UNSIGNED,
    primary key (id),
    FOREIGN KEY (id, ssn) REFERENCES people_starving(id, ssn)
);

CREATE TABLE resources_collected  (
	id int NOT NULL AUTO_INCREMENT, 
	people_necessities VARCHAR (60),
    food INT UNSIGNED,
    water INT UNSIGNED,
    ssn INT UNSIGNED,
    state_id CHAR(3),
    primary key (id),
    FOREIGN KEY (id, ssn) REFERENCES people_starving(id, ssn),
    FOREIGN KEY (id, state_id) REFERENCES state(id, state_id)
);

CREATE TABLE charity (
	id int NOT NULL AUTO_INCREMENT, 
	charity_id VARCHAR(30),
    food_pantry VARCHAR(30),
    people_shelter VARCHAR(30),
    ssn INT UNSIGNED,
    PRIMARY KEY (id, charity_id),
    FOREIGN KEY (id, ssn) REFERENCES people_starving(id, ssn)
);


INSERT INTO state (total_population,total_starving,resources,state_name,state_id)
VALUES (1000000000,1000000,5000, "Illinois", "IL"),
(999,99,9, "California", "CA"),
(10000,1000,100, "Texas", "TX"),
(39613493, 7521342, 20954, "Florida", "FL");

INSERT INTO people_starving(birth_date, name_person, ssn, state_id)
VALUES ("03/01/1999", "Tim", 359073867, "IL"),
("06/07/2011", "Bob", 459078953, "CA"),
("08/14/2014", "Hetu", 985354785, "TX"),
("07/21/2007", "Dean", 738493843, "FL");

INSERT INTO financial_condition(people_income, own_house, people_job, people_expenses, people_rent, ssn)
VALUES (20000, "No", "Cashier", 500, 900, 359073867),
(13000, "No", "Teller", 1000, 800, 459078953),
(25000, "No", "Factor Worker", 300, 1000, 985354785),
(14000, "No", "Labor", 600, 1100, 738493843);

INSERT INTO resources_collected (people_necessities, food, water, ssn, state_id)
VALUES ("Place, Toiletries",5,10, 359073867, "IL"),
("Place, Toiletries, medicines",3,15, 459078953, "CA"),
("Toiletries", 10, 17, 985354785, "TX"),
("Toiletries, medicines",54, 32, 738493843, "FL");

INSERT INTO charity(charity_id, food_pantry, people_shelter, ssn)
VALUES("RedCross", "Starving Kids", "Homeless Shelter", 359073867),
("BlueCross", "Feeding People", "Happy Shelter", 459078953),
("GreenCross", "Target Pantry", "Smile Shelter", 985354785),
("YellowCross", "Walgreens Pantry", "Laddoo Shelter", 738493843);
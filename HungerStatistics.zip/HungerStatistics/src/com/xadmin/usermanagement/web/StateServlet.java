package com.xadmin.usermanagement.web;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.usermanagement.dao.USerDAO;
import com.xadmin.usermanagement.model.State;

@WebServlet(name="StateServlet", urlPatterns={"/s"})
public class StateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private USerDAO userDAO;
	
	public void init() {
		userDAO = new USerDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/news":
				showNewForm(request, response);
				break;
			case "/inserts":
				insertState(request, response);
				break;
			case "/deletes":
				deleteState(request, response);
				break;
			case "/edits":
				showEditForm(request, response);
				break;
			case "/updates":
				updateState(request, response);
				break;
			default:
				listState(request, response);
				break;
			}
		} catch (SQLException | ParseException ex) {
			throw new ServletException(ex);
		}
	}

	private void listState(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<State> listState = userDAO.selectAllStates();
		request.setAttribute("listState", listState);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("state.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		State existingUser = userDAO.selectState(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("state.jsp");
		request.setAttribute("state", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertState(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		int total_population = Integer.parseInt(request.getParameter("total_population"));
		int total_starving = Integer.parseInt(request.getParameter("total_starving"));
		int resources = Integer.parseInt(request.getParameter("resources"));
		String state_name = request.getParameter("state_name");
		String state_id = request.getParameter("state_id");
		State newUser = new State(total_population, total_starving, resources, state_name, state_id);
		userDAO.insertState(newUser);
		response.sendRedirect("lists");
	}

	private void updateState(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		int total_population = Integer.parseInt(request.getParameter("total_population"));
		int total_starving = Integer.parseInt(request.getParameter("total_starving"));
		int resources = Integer.parseInt(request.getParameter("resources"));
		String state_name = request.getParameter("state_name");
		String state_id = request.getParameter("state_id");

		State newUser = new State(id, total_population, total_starving, resources, state_name, state_id);
		userDAO.updateState(newUser);
		response.sendRedirect("lists");
	}

	private void deleteState(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteState(id);
		response.sendRedirect("lists");

	}

}
package com.xadmin.usermanagement.web;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.usermanagement.dao.USerDAO;
import com.xadmin.usermanagement.model.PeopleStarving;


@WebServlet(name="UserServlet", urlPatterns={"/p"})
public class PeopleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private USerDAO userDAO;
	
	public void init() {
		userDAO = new USerDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException | ParseException ex) {
			throw new ServletException(ex);
		}
	}
	
//	private void listState(HttpServletRequest request, HttpServletResponse response)
//			throws SQLException, IOException, ServletException {
//		List<State> listState = userDAO.selectAllStates();
//		request.setAttribute("listState", listState);
//		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
//		dispatcher.forward(request, response);
//	}
//	
//	private void showNewFormState(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		RequestDispatcher dispatcher = request.getRequestDispatcher("state.jsp");
//		dispatcher.forward(request, response);
//	}
//
//	private void showEditFormState(HttpServletRequest request, HttpServletResponse response)
//			throws SQLException, ServletException, IOException {
//		int id = Integer.parseInt(request.getParameter("id"));
//		State existingUser = userDAO.selectState(id);
//		RequestDispatcher dispatcher = request.getRequestDispatcher("state.jsp");
//		request.setAttribute("state", existingUser);
//		dispatcher.forward(request, response);
//	}
//
//	private void insertState(HttpServletRequest request, HttpServletResponse response) 
//			throws SQLException, IOException, ParseException {
//		int total_population = Integer.parseInt(request.getParameter("total_population"));
//		int total_starving = Integer.parseInt(request.getParameter("total_starving"));
//		int resources = Integer.parseInt(request.getParameter("resources"));
//		String state_name = request.getParameter("state_name");
//		String state_id = request.getParameter("state_id");
//		State newUser = new State(total_population, total_starving, resources, state_name, state_id);
//		userDAO.insertState(newUser);
//		HttpServletResponse responses = response;
//		response.sendRedirect("lists");
//		responses.sendRedirect("list");
//	}
//
//	private void updateState(HttpServletRequest request, HttpServletResponse response) 
//			throws SQLException, IOException {
//		int id = Integer.parseInt(request.getParameter("id"));
//		int total_population = Integer.parseInt(request.getParameter("total_population"));
//		int total_starving = Integer.parseInt(request.getParameter("total_starving"));
//		int resources = Integer.parseInt(request.getParameter("resources"));
//		String state_name = request.getParameter("state_name");
//		String state_id = request.getParameter("state_id");
//
//		State newUser = new State(id, total_population, total_starving, resources, state_name, state_id);
//		userDAO.updateState(newUser);
//		response.sendRedirect("lists");
//	}
//
//	private void deleteState(HttpServletRequest request, HttpServletResponse response) 
//			throws SQLException, IOException {
//		int id = Integer.parseInt(request.getParameter("id"));
//		userDAO.deleteState(id);
//		response.sendRedirect("lists");
//	}
	
	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<PeopleStarving> listUser = userDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("people.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		PeopleStarving existingUser = userDAO.selectUser(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("people.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		String birth_date = request.getParameter("birth_date");
		String name_person = request.getParameter("name_person");
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");
		PeopleStarving newUser = new PeopleStarving(birth_date, name_person, ssn, state_id);
		userDAO.insertUser(newUser);
		response.sendRedirect("lists");
		HttpServletResponse responses = response;
		responses.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String birth_date = request.getParameter("birth_date");
		String name_person = request.getParameter("name_person");
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");

		PeopleStarving peopleStarving = new PeopleStarving(id, birth_date, name_person, ssn, state_id);
		userDAO.updateUser(peopleStarving);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteUser(id);
		response.sendRedirect("list");
	}

}
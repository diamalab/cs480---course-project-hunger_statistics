package com.xadmin.usermanagement.model;

public class Queries4 {
	protected String name_person;
	protected String state_id;
	
	public Queries4(String name_person, String state_id) {
		super();
		this.name_person = name_person;
		this.state_id = state_id;
	}

	public String getName_person() {
		return name_person;
	}

	public void setName_person(String name_person) {
		this.name_person = name_person;
	}

	public String getState_id() {
		return state_id;
	}

	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	
	
	
	
}
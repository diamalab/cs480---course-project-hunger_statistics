package com.xadmin.usermanagement.model;

public class Queries {
	protected String state_name;
	protected String state_id;
	
	public Queries(String state_name, String state_id) {
		super();
		this.state_name = state_name;
		this.state_id = state_id;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public String getState_id() {
		return state_id;
	}

	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	
	
	
}
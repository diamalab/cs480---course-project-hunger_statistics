package com.xadmin.usermanagement.model;

public class FinancialCondition {
	protected int people_income;
	protected String own_house;
	protected String people_job;
	protected int people_expenses;
	protected int people_rent;
	protected int ssn;
	private int id;
	
	public FinancialCondition() {
	}
	
	public FinancialCondition(int people_income, String own_house, String people_job, int people_expenses, int people_rent, int ssn) {
		super();
		this.people_income = people_income;
		this.own_house = own_house;
		this.people_job = people_job;
		this.people_expenses = people_expenses;
		this.people_rent = people_rent;
		this.ssn = ssn;
	}

	public FinancialCondition(int id, int people_income, String own_house, String people_job, int people_expenses, int people_rent, int ssn) {
		super();
		this.id = id;
		this.people_income = people_income;
		this.own_house = own_house;
		this.people_job = people_job;
		this.people_expenses = people_expenses;
		this.people_rent = people_rent;
		this.ssn = ssn;
	}

	public int getPeople_income() {
		return people_income;
	}

	public void setPeople_income(int people_income) {
		this.people_income = people_income;
	}

	public String getOwn_house() {
		return own_house;
	}

	public void setOwn_house(String own_house) {
		this.own_house = own_house;
	}

	public String getPeople_job() {
		return people_job;
	}

	public void setPeople_job(String people_job) {
		this.people_job = people_job;
	}

	public int getPeople_expenses() {
		return people_expenses;
	}

	public void setPeople_expenses(int people_expenses) {
		this.people_expenses = people_expenses;
	}

	public int getPeople_rent() {
		return people_rent;
	}

	public void setPeople_rent(int people_rent) {
		this.people_rent = people_rent;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
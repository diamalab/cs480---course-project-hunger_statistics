package com.xadmin.usermanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.xadmin.usermanagement.model.Charity;
import com.xadmin.usermanagement.model.FinancialCondition;
import com.xadmin.usermanagement.model.State;
import com.xadmin.usermanagement.model.PeopleStarving;
import com.xadmin.usermanagement.model.Queries;
import com.xadmin.usermanagement.model.Queries4;
import com.xadmin.usermanagement.model.Query3;
import com.xadmin.usermanagement.model.Query5;
import com.xadmin.usermanagement.model.ResourcesCollected;

public class USerDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/hunger_statistics?useSSL=false";
	private String jdbcUsername = "root";
	private String jdbcPassword = "K0u39571";

	private static final String INSERT_PEOPLE_SQL = "INSERT INTO people_starving" + "  (birth_date, name_person, ssn, state_id) VALUES " + " (?, ?, ?, ?);";
	private static final String SELECT_PEOPLE_BY_ID = "select id, birth_date, name_person, ssn, state_id from people_starving where id =?";
	private static final String SELECT_ALL_PEOPLE = "select * from people_starving";
	private static final String DELETE_PEOPLE_SQL = "delete from people_starving where id = ?;";
	private static final String UPDATE_PEOPLE_SQL = "update people_starving set birth_date = ?,name_person= ?, ssn =?, state_id = ? where id = ?;";
	
	private static final String INSERT_STATE_SQL = "INSERT INTO state" + "  (total_population, total_starving, resources, state_name, state_id) VALUES "+ " (?, ?, ?, ?, ?);";
	private static final String SELECT_STATE_BY_ID = "select id, total_population, total_starving, resources, state_name, state_id from state where id =?";
	private static final String SELECT_ALL_STATE = "select * from state";
	private static final String DELETE_STATE_SQL = "delete from state where id = ?;";
	private static final String UPDATE_STATE_SQL = "update state set total_population = ?,total_starving= ?, resources =?, state_name = ?, state_id = ? where id = ?;";
	
	private static final String INSERT_FINANCIAL_SQL = "INSERT INTO financial_condition" + "  (people_income, own_house, people_job, people_expenses, people_rent, ssn) VALUES "+ " (?, ?, ?, ?, ?, ?);";
	private static final String SELECT_FINANCIAL_BY_ID = "select id, people_income, own_house, people_job, people_expenses, people_rent, ssn from financial_condition where id =?";
	private static final String SELECT_ALL_FINANCIAL = "select * from financial_condition";
	private static final String DELETE_FINANCIAL_SQL = "delete from financial_condition where id = ?;";
	private static final String UPDATE_FINANCIAL_SQL = "update financial_condition set people_income = ?,own_house= ?, people_job =?, people_expenses = ?, people_rent = ?, ssn = ? where id = ?;";
	
	private static final String INSERT_RESOURCES_SQL = "INSERT INTO resources_collected" + "  (people_necessities, food, water, ssn, state_id) VALUES "+ " (?, ?, ?, ?, ?);";
	private static final String SELECT_RESOURCES_BY_ID = "select id, people_necessities, food, water, ssn, state_id from resources_collected where id =?";
	private static final String SELECT_ALL_RESOURCES = "select * from resources_collected";
	private static final String DELETE_RESOURCES_SQL = "delete from resources_collected where id = ?;";
	private static final String UPDATE_RESOURCES_SQL = "update resources_collected set people_necessities = ?,food= ?, water =?, ssn = ?, state_id = ? where id = ?;";
	
	private static final String INSERT_CHARITY_SQL = "INSERT INTO charity" + "  (charity_id, food_pantry, people_shelter, ssn) VALUES "+ " (?, ?, ?, ?);";
	private static final String SELECT_CHARITY_BY_ID = "select id, charity_id, food_pantry, people_shelter, ssn from charity where id =?";
	private static final String SELECT_ALL_CHARITY = "select * from charity";
	private static final String DELETE_CHARITY_SQL = "delete from charity where id = ?;";
	private static final String UPDATE_CHARITY_SQL = "update charity set charity_id = ?,food_pantry= ?, people_shelter =?, ssn = ? where id = ?;";
	
	private static final String QUERY_1 = "select state_name, state.state_id from state inner join people_starving on state.state_id = people_starving.state_id;";
	private static final String QUERY_2 = "Select * From financial_condition ORDER BY ssn DESC;";
	private static final String QUERY_3 = "Select MAX(ssn) as ssn FROM people_starving;";
	private static final String QUERY_4 = "SELECT people_starving.name_person, people_starving.state_id FROM people_starving  WHERE people_starving.id IN( SELECT financial_condition.id FROM financial_condition WHERE financial_condition.ssn > 40000);";
	private static final String QUERY_5 = "SELECT * FROM state WHERE total_population = 10000;";
	private static final String QUERY_6 = "SELECT state.state_name, state.state_id, state.resources FROM state left join people_starving ON state.state_id = people_starving.state_id and state.id = people_starving.id;";
	private static final String QUERY_7 = "SELECT  resources_collected.state_id, resources_collected.ssn FROM resources_collected right join people_starving ON resources_collected.state_id = people_starving.state_id;";
	private static final String QUERY_8 = "SELECT state_name, total_population, total_starving FROM state WHERE ID NOT IN (SELECT state_name FROM people_starving);";
	
	public USerDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertState(State newUser) throws SQLException {
		System.out.println(INSERT_STATE_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_STATE_SQL)) {
			preparedStatement.setInt(1, newUser.getTotal_population());
			preparedStatement.setInt(2, newUser.getTotal_starving());
			preparedStatement.setInt(3, newUser.getResources());
			preparedStatement.setString(4, newUser.getState_name());
			preparedStatement.setString(5, newUser.getState_id());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public State selectState(int id) {
		State user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_STATE_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int total_population = rs.getInt("total_population");
				int total_starving = rs.getInt("total_starving");
				int resources = rs.getInt("resources");
				String state_name = rs.getString("state_name");;
				String state_id = rs.getString("state_id");
				user = new State(id, total_population, total_starving, resources, state_name, state_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}
	
	public List<Queries> selectQuery1() {
		List<Queries> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_1);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String state_name = rs.getString(1);
				String state_id = rs.getString(2);
				users.add(new Queries(state_name, state_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	public List<FinancialCondition> selectQuery2() {
		List<FinancialCondition> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_2);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				int people_income = rs.getInt("people_income");
				String own_house = rs.getString("own_house");
				String people_job = rs.getString("people_job");
				int people_expenses = rs.getInt("people_expenses");
				int people_rent = rs.getInt("people_rent");
				int ssn = rs.getInt("ssn");
				users.add(new FinancialCondition(id, people_income, own_house, people_job, people_expenses, people_rent, ssn));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	public List<Query3> selectQuery3() {
		List<Query3> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_3);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String ssn = rs.getString(1);
				users.add(new Query3(ssn));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	public List<Queries4> selectQuery4() {
		List<Queries4> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_4);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name_person = rs.getString(1);
				String state_id = rs.getString(2);
				users.add(new Queries4(name_person, state_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	public List<ResourcesCollected> selectQuery7() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<ResourcesCollected> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_7);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int ssn = rs.getInt("ssn");
				String state_id = rs.getString("state_id");
				users.add(new ResourcesCollected(state_id, ssn));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	public List<State> selectAllStates() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<State> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_STATE);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				int total_population = rs.getInt("total_population");
				int total_starving = rs.getInt("total_starving");
				int resources = rs.getInt("resources");
				String state_name = rs.getString("state_name");;
				String state_id = rs.getString("state_id");
				users.add(new State(id, total_population, total_starving, resources, state_name, state_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}
	
	public List<State> selectQuery8() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<State> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_8);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String state_name = rs.getString("state_name");
				int total_population = rs.getInt("total_population");
				int total_starving = rs.getInt("total_starving");
				users.add(new State(state_name, total_population, total_starving));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public List<State> selectQuery6() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<State> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_6);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int resources = rs.getInt("resources");
				String state_name = rs.getString("state_name");;
				String state_id = rs.getString("state_id");
				users.add(new State(state_name, state_id, resources));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteState(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_STATE_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateState(State state) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_STATE_SQL);) {
			preparedStatement.setInt(1, state.getTotal_population());
			preparedStatement.setInt(2, state.getTotal_starving());
			preparedStatement.setInt(3, state.getResources());
			preparedStatement.setString(4, state.getState_name());
			preparedStatement.setString(5, state.getState_id());
			preparedStatement.setInt(6, state.getId());
			System.out.println("updated USer:"+preparedStatement);

			rowUpdated = preparedStatement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	
	public void insertUser(PeopleStarving newUser) throws SQLException {
		System.out.println(INSERT_PEOPLE_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PEOPLE_SQL)) {
			preparedStatement.setString(1, newUser.getBirth_date());
			preparedStatement.setString(2, newUser.getName_person());
			preparedStatement.setInt(3, newUser.getSsn());
			preparedStatement.setString(4, newUser.getState_id());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}
	
	public List<State> selectQuery5() {
		List<State> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(QUERY_5);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int total_population = rs.getInt("total_population");
				int total_starving = rs.getInt("total_starving");
				int resources = rs.getInt("resources");
				String state_name = rs.getString("state_name");
				String state_id = rs.getString("state_id");
				users.add(new State(total_population, total_starving, resources, state_name, state_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public PeopleStarving selectUser(int id) {
		PeopleStarving user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PEOPLE_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String birth_date = rs.getString("birth_date");
				String name_person = rs.getString("name_person");
				int ssn = rs.getInt("ssn");
				String state_id = rs.getString("state_id");
				user = new PeopleStarving(id, birth_date, name_person, ssn, state_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<PeopleStarving> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<PeopleStarving> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PEOPLE);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				String birth_date = rs.getString("birth_date");
				String name_person = rs.getString("name_person");
				int ssn = rs.getInt("ssn");
				String state_id = rs.getString("state_id");
				users.add(new PeopleStarving(id, birth_date, name_person, ssn, state_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_PEOPLE_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(PeopleStarving peopleStarving) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_PEOPLE_SQL);) {
			statement.setString(1, peopleStarving.getBirth_date());
			statement.setString(2, peopleStarving.getName_person());
			statement.setInt(3, peopleStarving.getSsn());
			statement.setString(4, peopleStarving.getState_id());
			statement.setInt(5, peopleStarving.getId());
			System.out.println("updated USer:"+statement);

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
	
	public void insertFinancial(FinancialCondition newUser) throws SQLException {
		System.out.println(INSERT_FINANCIAL_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FINANCIAL_SQL)) {
			preparedStatement.setInt(1, newUser.getPeople_income());
			preparedStatement.setString(2, newUser.getOwn_house());
			preparedStatement.setString(3, newUser.getPeople_job());
			preparedStatement.setFloat(4, newUser.getPeople_expenses());
			preparedStatement.setFloat(5, newUser.getPeople_rent());
			preparedStatement.setInt(6, newUser.getSsn());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public FinancialCondition selectFinancial(int id) {
		FinancialCondition user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_FINANCIAL_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int people_income = rs.getInt("people_income");
				String own_house = rs.getString("own_house");
				String people_job = rs.getString("people_job");
				int people_expenses = rs.getInt("people_expenses");
				int people_rent = rs.getInt("people_rent");
				int ssn = rs.getInt("ssn");
				user = new FinancialCondition(id, people_income, own_house, people_job, people_expenses, people_rent, ssn);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<FinancialCondition> selectAllFinancial() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<FinancialCondition> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_FINANCIAL);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				int people_income = rs.getInt("people_income");
				String own_house = rs.getString("own_house");
				String people_job = rs.getString("people_job");
				int people_expenses = rs.getInt("people_expenses");
				int people_rent = rs.getInt("people_rent");
				int ssn = rs.getInt("ssn");
				users.add(new FinancialCondition(id, people_income, own_house, people_job, people_expenses, people_rent, ssn));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteFinancial(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_FINANCIAL_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateFinancial(FinancialCondition financial) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_FINANCIAL_SQL);) {
			preparedStatement.setInt(1, financial.getPeople_income());
			preparedStatement.setString(2, financial.getOwn_house());
			preparedStatement.setString(3, financial.getPeople_job());
			preparedStatement.setFloat(4, financial.getPeople_expenses());
			preparedStatement.setFloat(5, financial.getPeople_rent());
			preparedStatement.setInt(6, financial.getSsn());
			preparedStatement.setInt(7, financial.getId());
			System.out.println("updated USer:"+preparedStatement);

			rowUpdated = preparedStatement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	
	public void insertResources(ResourcesCollected newUser) throws SQLException {
		System.out.println(INSERT_RESOURCES_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_RESOURCES_SQL)) {
			preparedStatement.setString(1, newUser.getPeople_necessities());
			preparedStatement.setInt(2, newUser.getFood());
			preparedStatement.setInt(3, newUser.getWater());
			preparedStatement.setInt(4, newUser.getSsn());
			preparedStatement.setString(5, newUser.getState_id());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public ResourcesCollected selectResources(int id) {
		ResourcesCollected user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_RESOURCES_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String people_necessities = rs.getString("people_necessities");
				int food = rs.getInt("food");
				int water = rs.getInt("water");
				int ssn = rs.getInt("ssn");
				String state_id = rs.getString("state_id");
				user = new ResourcesCollected(id, people_necessities, food, water, ssn, state_id);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<ResourcesCollected> selectAllResources() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<ResourcesCollected> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_RESOURCES);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				String people_necessities = rs.getString("people_necessities");
				int food = rs.getInt("food");
				int water = rs.getInt("water");
				int ssn = rs.getInt("ssn");
				String state_id = rs.getString("state_id");
				users.add(new ResourcesCollected(id, people_necessities, food, water, ssn, state_id));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteResources(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_RESOURCES_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateResources(ResourcesCollected resources) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_RESOURCES_SQL);) {
			preparedStatement.setString(1, resources.getPeople_necessities());
			preparedStatement.setInt(2, resources.getFood());
			preparedStatement.setInt(3, resources.getWater());
			preparedStatement.setInt(4, resources.getSsn());
			preparedStatement.setString(5, resources.getState_id());
			preparedStatement.setInt(6, resources.getId());
			System.out.println("updated USer:"+preparedStatement);

			rowUpdated = preparedStatement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
	
	public void insertCharity(Charity newUser) throws SQLException {
		System.out.println(INSERT_CHARITY_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CHARITY_SQL)) {
			preparedStatement.setString(1, newUser.getCharity_id());
			preparedStatement.setString(2, newUser.getFood_pantry());
			preparedStatement.setString(3, newUser.getPeople_shelter());
			preparedStatement.setInt(4, newUser.getSsn());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Charity selectCharity(int id) {
		Charity user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CHARITY_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String charity_id = rs.getString("charity_id");
				String food_pantry = rs.getString("food_pantry");
				String people_shelter = rs.getString("people_shelter");
				int ssn = rs.getInt("ssn");
				user = new Charity(id, charity_id, food_pantry, people_shelter, ssn);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return user;
	}

	public List<Charity> selectAllCharity() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Charity> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CHARITY);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				String charity_id = rs.getString("charity_id");
				String food_pantry = rs.getString("food_pantry");
				String people_shelter = rs.getString("people_shelter");
				int ssn = rs.getInt("ssn");
				users.add(new Charity(id, charity_id, food_pantry, people_shelter, ssn));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteCharity(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_CHARITY_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateCharity(Charity charity) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CHARITY_SQL);) {
			preparedStatement.setString(1, charity.getCharity_id());
			preparedStatement.setString(2, charity.getFood_pantry());
			preparedStatement.setString(3, charity.getPeople_shelter());
			preparedStatement.setInt(4, charity.getSsn());
			preparedStatement.setInt(5, charity.getId());
			System.out.println("updated USer:"+preparedStatement);

			rowUpdated = preparedStatement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

}
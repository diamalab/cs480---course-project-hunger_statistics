package user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.domain.User;



/**
 * DDL functions performed in database
 * @author changxin bai
 *
 */
public class UserDao {    
	/**
	 * get the search result with username 
	 * @param name_person
	 * @return
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public User findByUsername(String name_person) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		User user = new User();
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();;
			Connection connect;
			try {
				connect = DriverManager
				          .getConnection("jdbc:mysql://localhost:3306/bookstore?"
					              + "user=root&password=K0u39571");
				Statement statement = connect.createStatement();
				statement.executeUpdate("DROP DATABASE bookstore;");
			}
				catch(SQLException e) {
			
			connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/hunger_statistics?"
				              + "user=root&password=K0u39571");
			
			
		    String sql = "select * from people_starving where name_person=?";
		    PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setString(1,name_person);
		    ResultSet resultSet = preparestatement.executeQuery();
		    //ResultSet resultSet  = preparestatement.executeUpdate();
		    while(resultSet.next()){
		    	String user_name = resultSet.getString("name_person");
		    	if(user_name.equals(name_person)){
		    		user.setUsername(resultSet.getString("name_person"));
		    		user.setPassword(resultSet.getString("state"));
		    		user.setEmail(resultSet.getString("birth_date"));
		    	}
		    }
		}
		    
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		return user;
	}	
	
	/**
	 * insert User
	 * @param user
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void add(User user) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/hunger_statistics?"
				              + "user=root&password=K0u39571");
						
			String sql = "insert into people_starving values(?,?,?)";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
		    preparestatement.setString(1,user.getUsername());
		    preparestatement.setString(2,user.getPassword());
		    preparestatement.setString(3,user.getEmail());
		    preparestatement.executeUpdate();
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	
	public List<Object> findall() throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		List<Object> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/hunger_statistics?"
				              + "user=root&password=K0u39571");
			
			String sql = "select * from people_starving";
			PreparedStatement preparestatement = connect.prepareStatement(sql); 
			ResultSet resultSet = preparestatement.executeQuery();
			
			while(resultSet.next()){
				User user = new User();
				user.setUsername(resultSet.getString("name_person"));
	    		user.setPassword(resultSet.getString("state"));
	    		user.setEmail(resultSet.getString("birth_date"));
	    		list.add(user);
			 }
			 
		} catch(SQLException e) {
			throw new RuntimeException(e);
		}
		return list;
		
	}
		
}

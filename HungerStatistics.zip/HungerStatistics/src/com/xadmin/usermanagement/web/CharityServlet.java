package com.xadmin.usermanagement.web;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.usermanagement.dao.USerDAO;
import com.xadmin.usermanagement.model.Charity;

@WebServlet(name="CharityServlet", urlPatterns={"/c"})
public class CharityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private USerDAO userDAO;
	
	public void init() {
		userDAO = new USerDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/newc":
				showNewFormCharity(request, response);
				break;
			case "/insertc":
				insertCharity(request, response);
				break;
			case "/deletec":
				deleteCharity(request, response);
				break;
			case "/editc":
				showEditFormCharity(request, response);
				break;
			case "/updatec":
				updateCharity(request, response);
				break;
			default:
				listCharity(request, response);
				break;
			}
		} catch (SQLException | ParseException ex) {
			throw new ServletException(ex);
		}
	}

	private void listCharity(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Charity> listCharity = userDAO.selectAllCharity();
		request.setAttribute("listCharity", listCharity);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewFormCharity(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("charity.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormCharity(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Charity existingUser = userDAO.selectCharity(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("charity.jsp");
		request.setAttribute("charity", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertCharity(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		String charity_id = request.getParameter("charity_id");
		String food_pantry = request.getParameter("food_pantry");
		String people_shelter = request.getParameter("people_shelter");
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		
		Charity newUser = new Charity(charity_id, food_pantry, people_shelter, ssn);
		userDAO.insertCharity(newUser);
		response.sendRedirect("listc");
	}

	private void updateCharity(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String charity_id = request.getParameter("charity_id");
		String food_pantry = request.getParameter("food_pantry");
		String people_shelter = request.getParameter("people_shelter");
		int ssn = Integer.parseInt(request.getParameter("ssn"));

		Charity newUser = new Charity(id, charity_id, food_pantry, people_shelter, ssn);
		userDAO.updateCharity(newUser);
		response.sendRedirect("listc");
	}

	private void deleteCharity(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteCharity(id);
		response.sendRedirect("listc");
	}

}
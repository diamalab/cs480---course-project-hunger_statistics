package com.xadmin.usermanagement.web;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.usermanagement.dao.USerDAO;
import com.xadmin.usermanagement.model.ResourcesCollected;

@WebServlet(name="ResourcesServlet", urlPatterns={"/r"})
public class ResourcesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private USerDAO userDAO;
	
	public void init() {
		userDAO = new USerDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/*newr":
				showNewResources(request, response);
				break;
			case "/*insertr":
				insertResources(request, response);
				break;
			case "/*deleter":
				deleteResources(request, response);
				break;
			case "/*editr":
				showEditFormResources(request, response);
				break;
			case "/*updater":
				updateResources(request, response);
				break;
			default:
				listResources(request, response);
				break;
			}
		} catch (SQLException | ParseException ex) {
			throw new ServletException(ex);
		}
	}

	private void listResources(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<ResourcesCollected> listResources = userDAO.selectAllResources();
		request.setAttribute("listResources", listResources);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewResources(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("resources.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormResources(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		ResourcesCollected existingUser = userDAO.selectResources(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("resources.jsp");
		request.setAttribute("resources", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertResources(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		String people_necessities = request.getParameter("people_necessities");
		int food = Integer.parseInt(request.getParameter("food"));
		int water = Integer.parseInt(request.getParameter("water"));
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");
		ResourcesCollected newUser = new ResourcesCollected(people_necessities, food, water, ssn, state_id);
		userDAO.insertResources(newUser);
		response.sendRedirect("listr");
	}

	private void updateResources(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String people_necessities = request.getParameter("people_necessities");
		int food = Integer.parseInt(request.getParameter("food"));
		int water = Integer.parseInt(request.getParameter("water"));
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");
		
		ResourcesCollected newUser = new ResourcesCollected(id, people_necessities, food, water, ssn, state_id);
		userDAO.updateResources(newUser);
		response.sendRedirect("listr");
	}

	private void deleteResources(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteResources(id);
		response.sendRedirect("listr");

	}

}
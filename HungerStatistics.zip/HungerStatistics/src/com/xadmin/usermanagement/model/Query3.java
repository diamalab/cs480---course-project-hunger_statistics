package com.xadmin.usermanagement.model;

public class Query3 {
	protected String ssn;
	
	public Query3(String ssn) {
		super();
		this.ssn = ssn;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	
	
	
	
	
}
package com.xadmin.usermanagement.web;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.usermanagement.dao.USerDAO;
import com.xadmin.usermanagement.model.Charity;
import com.xadmin.usermanagement.model.FinancialCondition;
import com.xadmin.usermanagement.model.PeopleStarving;
import com.xadmin.usermanagement.model.Queries;
import com.xadmin.usermanagement.model.Queries4;
import com.xadmin.usermanagement.model.Query3;
import com.xadmin.usermanagement.model.Query5;
import com.xadmin.usermanagement.model.ResourcesCollected;
import com.xadmin.usermanagement.model.State;

@WebServlet(name="Servlet", urlPatterns={"/"})
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private USerDAO userDAO;
	
	public void init() {
		userDAO = new USerDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			
			case "/query1":
				querie1(request, response);
				break;
			case "/query2":
				querie2(request, response);
				break;
			case "/query3":
				querie3(request, response);
				break;
			case "/query4":
				querie4(request, response);
				break;
			case "/query5":
				querie5(request, response);
				break;
			case "/query6":
				querie6(request, response);
				break;
			case "/query7":
				querie7(request, response);
				break;
			case "/query8":
				querie8(request, response);
				break;
					
			case "/news":
				showNewFormState(request, response);
				break;
			case "/inserts":
				insertState(request, response);
				break;
			case "/deletes":
				deleteState(request, response);
				break;
			case "/edits":
				showEditFormState(request, response);
				break;
			case "/updates":
				updateState(request, response);
				break;
			case "lists":
				listState(request, response);
				break;
				
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertUser(request, response);
				break;
			case "/delete":
				deleteUser(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateUser(request, response);
				break;
			case "/list":
				listUser(request, response);
				break;
				
			case "/newf":
				showNewFormFinancial(request, response);
				break;
			case "/insertf":
				insertFinancial(request, response);
				break;
			case "/deletef":
				deleteFinancial(request, response);
				break;
			case "/editf":
				showEditFormFinancial(request, response);
				break;
			case "/updatef":
				updateFinancial(request, response);
				break;
			case "/listf":
				listFinancial(request, response);
				break;
				
			case "/newr":
				showNewResources(request, response);
				break;
			case "/insertr":
				insertResources(request, response);
				break;
			case "/deleter":
				deleteResources(request, response);
				break;
			case "/editr":
				showEditFormResources(request, response);
				break;
			case "/updater":
				updateResources(request, response);
				break;
			case "listr":
				listResources(request, response);
				break;
				
			case "/newc":
				showNewFormCharity(request, response);
				break;
			case "/insertc":
				insertCharity(request, response);
				break;
			case "/deletec":
				deleteCharity(request, response);
				break;
			case "/editc":
				showEditFormCharity(request, response);
				break;
			case "/updatec":
				updateCharity(request, response);
				break;
			case "/listc":
				listCharity(request, response);
				break;
				
			default:
				listState(request, response);
				break;
			}
		} catch (SQLException | ParseException ex) {
			throw new ServletException(ex);
		}
	}

	private void querie1(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List <Queries> query1 = userDAO.selectQuery1();
		request.setAttribute("query1", query1);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query1.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie2(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<FinancialCondition> query2 = userDAO.selectQuery2();
		request.setAttribute("query2", query2);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query2.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie3(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List <Query3> query3 = userDAO.selectQuery3();
		request.setAttribute("query3", query3);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query3.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie4(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List <Queries4> query4 = userDAO.selectQuery4();
		request.setAttribute("query4", query4);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query4.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie5(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List <State> query5 = userDAO.selectQuery5();
		request.setAttribute("query5", query5);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query5.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie6(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List <State> query6 = userDAO.selectQuery6();
		request.setAttribute("query6", query6);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query6.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie8(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List <State> query8 = userDAO.selectQuery8();
		request.setAttribute("query8", query8);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query8.jsp");
		dispatcher.forward(request, response);
	}
	
	private void querie7(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<ResourcesCollected> query7 = userDAO.selectAllResources();
		request.setAttribute("query7", query7);
		RequestDispatcher dispatcher = request.getRequestDispatcher("query7.jsp");
		dispatcher.forward(request, response);
	}
	
	private void listState(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<State> listState = userDAO.selectAllStates();
		request.setAttribute("listState", listState);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}


	private void showNewFormState(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("state.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormState(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		State existingUser = userDAO.selectState(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("state.jsp");
		request.setAttribute("state", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertState(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		int total_population = Integer.parseInt(request.getParameter("total_population"));
		int total_starving = Integer.parseInt(request.getParameter("total_starving"));
		int resources = Integer.parseInt(request.getParameter("resources"));
		String state_name = request.getParameter("state_name");
		String state_id = request.getParameter("state_id");
		State newUser = new State(total_population, total_starving, resources, state_name, state_id);
		userDAO.insertState(newUser);
		response.sendRedirect("lists");
	}

	private void updateState(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		int total_population = Integer.parseInt(request.getParameter("total_population"));
		int total_starving = Integer.parseInt(request.getParameter("total_starving"));
		int resources = Integer.parseInt(request.getParameter("resources"));
		String state_name = request.getParameter("state_name");
		String state_id = request.getParameter("state_id");

		State newUser = new State(id, total_population, total_starving, resources, state_name, state_id);
		userDAO.updateState(newUser);
		response.sendRedirect("lists");
	}

	private void deleteState(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteState(id);
		response.sendRedirect("lists");

	}
	
	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<PeopleStarving> listUser = userDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("people.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		PeopleStarving existingUser = userDAO.selectUser(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("people.jsp");
		request.setAttribute("user", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		String birth_date = request.getParameter("birth_date");
		String name_person = request.getParameter("name_person");
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");
		PeopleStarving newUser = new PeopleStarving(birth_date, name_person, ssn, state_id);
		userDAO.insertUser(newUser);
		response.sendRedirect("list");
	}

	private void updateUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String birth_date = request.getParameter("birth_date");
		String name_person = request.getParameter("name_person");
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");

		PeopleStarving peopleStarving = new PeopleStarving(id, birth_date, name_person, ssn, state_id);
		userDAO.updateUser(peopleStarving);
		response.sendRedirect("list");
	}

	private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteUser(id);
		response.sendRedirect("list");
	}
	
	private void listFinancial(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<FinancialCondition> listFinancial = userDAO.selectAllFinancial();
		request.setAttribute("listFinancial", listFinancial);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewFormFinancial(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("financial.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormFinancial(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		FinancialCondition existingUser = userDAO.selectFinancial(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("financial.jsp");
		request.setAttribute("financial", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertFinancial(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		int people_income = Integer.parseInt(request.getParameter("people_income"));
		String own_house = request.getParameter("own_house");
		String people_job = request.getParameter("people_job");
		int people_expenses = Integer.parseInt(request.getParameter("people_expenses"));
		int people_rent = Integer.parseInt(request.getParameter("people_rent"));
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		
		FinancialCondition newUser = new FinancialCondition(people_income, own_house, people_job, people_expenses, people_rent, ssn);
		userDAO.insertFinancial(newUser);
		response.sendRedirect("listf");
	}

	private void updateFinancial(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		int people_income = Integer.parseInt(request.getParameter("people_income"));
		String own_house = request.getParameter("own_house");
		String people_job = request.getParameter("people_job");
		int people_expenses = Integer.parseInt(request.getParameter("people_expenses"));
		int people_rent = Integer.parseInt(request.getParameter("people_rent"));
		int ssn = Integer.parseInt(request.getParameter("ssn"));

		FinancialCondition newUser = new FinancialCondition(id, people_income, own_house, people_job, people_expenses, people_rent, ssn);
		userDAO.updateFinancial(newUser);
		response.sendRedirect("listf");
	}

	private void deleteFinancial(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteFinancial(id);
		response.sendRedirect("listf");

	}
	
	private void listResources(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<ResourcesCollected> listResources = userDAO.selectAllResources();
		request.setAttribute("listResources", listResources);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewResources(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("resources.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormResources(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		ResourcesCollected existingUser = userDAO.selectResources(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("resources.jsp");
		request.setAttribute("resources", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertResources(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		String people_necessities = request.getParameter("people_necessities");
		int food = Integer.parseInt(request.getParameter("food"));
		int water = Integer.parseInt(request.getParameter("water"));
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");
		ResourcesCollected newUser = new ResourcesCollected(people_necessities, food, water, ssn, state_id);
		userDAO.insertResources(newUser);
		response.sendRedirect("listr");
	}

	private void updateResources(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String people_necessities = request.getParameter("people_necessities");
		int food = Integer.parseInt(request.getParameter("food"));
		int water = Integer.parseInt(request.getParameter("water"));
		int ssn = Integer.parseInt(request.getParameter("ssn"));
		String state_id = request.getParameter("state_id");
		
		ResourcesCollected newUser = new ResourcesCollected(id, people_necessities, food, water, ssn, state_id);
		userDAO.updateResources(newUser);
		response.sendRedirect("listr");
	}

	private void deleteResources(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteResources(id);
		response.sendRedirect("listr");

	}
	
	private void listCharity(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Charity> listCharity = userDAO.selectAllCharity();
		request.setAttribute("listCharity", listCharity);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewFormCharity(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("charity.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditFormCharity(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Charity existingUser = userDAO.selectCharity(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("charity.jsp");
		request.setAttribute("charity", existingUser);
		dispatcher.forward(request, response);

	}

	private void insertCharity(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException, ParseException {
		String charity_id = request.getParameter("charity_id");
		String food_pantry = request.getParameter("food_pantry");
		String people_shelter = request.getParameter("people_shelter");
		int ssn = Integer.parseInt(request.getParameter("ssn"));
	
		Charity newUser = new Charity(charity_id, food_pantry, people_shelter, ssn);
		userDAO.insertCharity(newUser);
		response.sendRedirect("listc");
	}

	private void updateCharity(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String charity_id = request.getParameter("charity_id");
		String food_pantry = request.getParameter("food_pantry");
		String people_shelter = request.getParameter("people_shelter");
		int ssn = Integer.parseInt(request.getParameter("ssn"));

		Charity newUser = new Charity(id, charity_id, food_pantry, people_shelter, ssn);
		userDAO.updateCharity(newUser);
		response.sendRedirect("listc");
	}

	private void deleteCharity(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		userDAO.deleteCharity(id);
		response.sendRedirect("listc");
	}
}
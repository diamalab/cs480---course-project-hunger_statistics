package com.xadmin.usermanagement.model;

public class state {
	protected int birth_date;
	protected String name;
	protected String state;
	protected String age;
	
	public state() {
	}
	
	public state(String name, String email, String country) {
		super();
		this.name = name;
		this.state = email;
		this.age = country;
	}

	public state(int id, String name, String email, String country) {
		super();
		this.birth_date = id;
		this.name = name;
		this.state = email;
		this.age = country;
	}

	public int getId() {
		return birth_date;
	}
	public void setId(int id) {
		this.birth_date = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return state;
	}
	public void setEmail(String email) {
		this.state = email;
	}
	public String getCountry() {
		return age;
	}
	public void setCountry(String country) {
		this.age = country;
	}
}
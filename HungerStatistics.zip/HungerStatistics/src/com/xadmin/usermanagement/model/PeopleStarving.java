package com.xadmin.usermanagement.model;

public class PeopleStarving {
	protected String birth_date;
	protected String name_person;
	protected int ssn;
	protected String state_id;
	private int id;
	
	public PeopleStarving() {
	}
	
	public PeopleStarving(String birth_date, String name_person, int ssn, String state_id) {
		super();
		this.birth_date = birth_date;
		this.name_person = name_person;
		this.ssn = ssn;
		this.state_id = state_id;
	}

	public PeopleStarving(int id, String birth_date, String name_person, int ssn, String state_id) {
		super();
		this.id = id;
		this.birth_date = birth_date;
		this.name_person = name_person;
		this.ssn = ssn;
		this.state_id = state_id;
	}

	public String getBirth_date() {
		return birth_date;
	}

	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}

	public String getName_person() {
		return name_person;
	}

	public void setName_person(String name_person) {
		this.name_person = name_person;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public String getState_id() {
		return state_id;
	}

	public void setState_id(String state_id) {
		this.state_id = state_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
}
package com.xadmin.usermanagement.model;

public class ResourcesCollected {
	protected String people_necessities;
	protected int food;
	protected int water;
	protected int ssn;
	protected String state_id;
	private int id;
	
	public ResourcesCollected() {
	}
	
	public ResourcesCollected(String people_necessities, int food, int water, int ssn, String state_id) {
		super();
		this.people_necessities = people_necessities;
		this.food = food;
		this.water = water;
		this.ssn = ssn;
		this.state_id = state_id;
	}
	
	public ResourcesCollected(String state_id, int ssn) {
		super();
		this.ssn = ssn;
		this.state_id = state_id;
	}

	public ResourcesCollected(int id, String people_necessities, int food, int water, int ssn, String state_id) {
		super();
		this.id = id;
		this.people_necessities = people_necessities;
		this.food = food;
		this.water = water;
		this.ssn = ssn;
		this.state_id = state_id;
	}

	public String getPeople_necessities() {
		return people_necessities;
	}

	public void setPeople_necessities(String people_necessities) {
		this.people_necessities = people_necessities;
	}

	public int getFood() {
		return food;
	}

	public void setFood(int food) {
		this.food = food;
	}

	public int getWater() {
		return water;
	}

	public void setWater(int water) {
		this.water = water;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public String getState_id() {
		return state_id;
	}

	public void setState_id(String state_id) {
		this.state_id = state_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}